# !/bin/sh
echo "---------------------------------->lte sh<----------------------------------"
auto=1
cd /home/root/wupeng
insmod rtl8188eu.ko
cd LTELocation/driver
./load.sh
wlandevice=$(iwconfig 2>/dev/null | head -1 | cut -d ' ' -f 1)
route=201807001
wpa=0
if [ ${route:0:4} -gt 0062 ];then
    wpa=1
fi
ifconfig $wlandevice up
iwconfig $wlandevice power off
ifconfig $wlandevice 192.168.43.116
sleep 3
if [ $wpa -eq 1 ];then
    wpa_passphrase $route ltedw123 > wpa_inv.conf
    wpa_supplicant -B -i $wlandevice -Dwext -cwpa_inv.conf
else
    iwconfig $wlandevice essid $route
fi
cd /home/root/wupeng/LTELocation
while read LINE;do
    newIndex="$LINE"
done < logIndex
newIndex=`expr $newIndex + 1`
if [ $newIndex = "31" ];then
    newIndex="1"
fi
if [ $auto -eq 1 ];then
    echo $newIndex > logIndex
    ./FFTWCheck &
    ./LTE_Location_r &> run$newIndex.log &
fi
./LTEAPConnect $wlandevice $route $wpa > apconnect.log &
